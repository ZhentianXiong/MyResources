package com.mindata.blockmanager.bean;

/**
 * @author wuweifeng wrote on 2018/3/19.
 */
public class BaseData {
    private int code;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
