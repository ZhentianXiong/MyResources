package com.mindata.blockmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MdBlockchainManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MdBlockchainManagerApplication.class, args);
	}
}
